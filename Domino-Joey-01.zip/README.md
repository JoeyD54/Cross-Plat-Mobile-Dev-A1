# Cross-Plat-Mobile-Dev-A1
First assignment for cross platform course. Basic "about me" website with contact info.
